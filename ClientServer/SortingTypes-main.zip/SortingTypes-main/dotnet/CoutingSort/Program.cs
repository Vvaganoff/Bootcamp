﻿20.CreateArray(0, 8)
  .Show()
  .SortCounting()
  .Show();